# Changelog

This is a changelog file

# Christmas 1970

Introducing this [new package](nested-sub-dir-a/)

and this [non-existing package](dead-end) that misses a trailing slash

and this [package without a readme](nested-sub-dir-b/)

as necessary for [this sibling package](../sub-dir-b)
