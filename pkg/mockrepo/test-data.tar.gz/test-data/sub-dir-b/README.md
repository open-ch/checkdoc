# Readme B

Some documentation for package sub-dir-b.

You may also be interested in [this sibling package](../sub-dir-a/README)
